<?php
ob_start(); 
session_start();

$con = mysqli_connect("localhost", "root", "", "deadsprint");

if(mysqli_connect_errno()) 
{
	echo "Did not connect: " . mysqli_connect_errno();
}

?>
<?php 

$firname = ""; 
$lasname = "";
$email1 = ""; 
$email2 = "";
$password = "";
$password2 = ""; 
$date = ""; 
$error_array = array(); 

if(isset($_POST['register_button'])){

$firname = strip_tags($_POST['reg_fname']);
$firname = str_replace(' ', '', $firname); 
$lasname = strip_tags($_POST['reg_lname']); 
$lasname = str_replace(' ', '', $lasname); 
$email1 = strip_tags($_POST['reg_email']); 
$email1 = str_replace(' ', '', $email1); 
$email2 = strip_tags($_POST['reg_email2']);
$email2 = str_replace(' ', '', $email2); 
$password = strip_tags($_POST['reg_password']); 
$password2 = strip_tags($_POST['reg_password2']); 
$date = date("Y-m-d"); 


//password validation 

	if($password != $password2) {
		array_push($error_array,  "Your passwords do not match<br>");
	}
	else {
	if (!empty($password))
	{
		// Validate password strength
		$uppercase = preg_match('@[A-Z]@', $password);
		$lowercase = preg_match('@[a-z]@', $password);
		$number = preg_match('@[0-9]@', $password);
		$specialChars = preg_match('@[^\w]@', $password);

		if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
			array_push($error_array, "Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.<br>");
		}
	}
}
//email validation 
if($email1 == $email2) {
		if(filter_var($email1, FILTER_VALIDATE_EMAIL)) {
			$email1 = filter_var($email1, FILTER_VALIDATE_EMAIL);
			$e_check = mysqli_query($con, "SELECT email FROM users WHERE email='$email1'");
			$num_rows = mysqli_num_rows($e_check);
			if($num_rows > 0) {
				array_push($error_array, "This Email is already in use<br>");
			}
		}
		else {
			array_push($error_array, "Your email format is correct<br>");
		}
	}
	else {
		array_push($error_array, "The Emails you have entered do not match<br>");
	}

//name validation
if(strlen($firname) > 30 || strlen($firname) < 2) {
	array_push($error_array, "Your first name has to be between 2 and 30 characters<br>");
	}
if(strlen($lasname) > 30 || strlen($lasname) < 2) {
	array_push($error_array,  "Your last name has to be between 2 and 30 characters<br>");
	}
	}


	if(empty($error_array)) {
		$password = md5($password); //This will Encrypt the password before it sends it into the to database
		$username = strtolower($firname . "_" . $lasname);
		$check_username_query = mysqli_query($con, "SELECT username FROM users WHERE username='$username'");
		$i = 0; 
		 while(mysqli_num_rows($check_username_query) != 0){
			 $i++;
			 $username = $username."_".$i;
			 $check_username_query = mysqli_query($con, "SELECT username FROM users WHERE username='$username'");
		 }
		 $rand = rand(1, 2);
		if($rand == 1)
			$profile_pic = "handler/head_deep_blue.png";
		else if($rand == 2)
			$profile_pic = "handler/head_pomegranate.png";
		$query = mysqli_query($con, "INSERT INTO users VALUES (NULL, '$firname', '$lasname', '$username', '$email1', '$password', '$date', '$profile_pic', '0', '0', 'no', ',')");	 
	}
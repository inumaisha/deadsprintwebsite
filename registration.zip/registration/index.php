<?php 
include("header.php");
include("Person.php");
include("Post.php");


if(isset($_POST['post'])){
	$post = new Post($con, $userLoggedIn);
	$post->submitPost($_POST['post_text'], 'none');
	
}
 ?>
 <div class="user_details column">
		<a>  <img src="<?php echo $user['profile_pic']; ?>"> </a>

		<div class="user_details_left_right">
		
			<?php 
			echo $user['first_name'] . " " . $user['last_name'];

			 ?>
			</a>
			<br>
			<?php echo "Posts: " . $user['num_posts']. "<br>"; 
			echo "Likes: " . $user['num_likes'];

			?>
	</div>

</div>

<div class="main_column column">
		<form class="post_form" action="index.php" method="POST" enctype="multipart/form-data">
			<textarea name="post_text" id="post_text" placeholder="How was your adventure?"></textarea>
			<input type="submit" name="post" id="post_button" value="Post">
			<hr>

		</form>
		<?php
		$post = new Post($con, $userLoggedIn);
		$post ->loadPostsFriends();
		?>

		


		<div>


		


	</div>
</body>
</html>
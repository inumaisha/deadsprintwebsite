
<?php
require 'config.php'; 
require 'handler/register_handler.php';
require 'handler/login_handler.php';
?>
<html>
<head>
<title>Dead sprint</title>
	<link rel="stylesheet" type="text/css" href="css/register_page_css.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="js/register.js"></script>
</head>
<body>
<?php  

	if(isset($_POST['register_button'])) {
		echo '
		<script>

		$(document).ready(function() {
			$("#first").hide();
			$("#second").show();
		});

		</script>

		';
	}


	?>
	
	<div class="login_box"> 
		<div class="login_header">
		<h1>Deadsprint</h1>
		login or sign up to start your adventure! 

	</div>



	<div id="first">

				<form action="register.php" method="POST">
					<input type="email" name="log_email" placeholder="Email Address" value="<?php 
					if(isset($_SESSION['log_email'])) {
						echo $_SESSION['log_email'];
					} 
					?>" required>
					<br>
					<input type="password" name="log_password" placeholder="Password">
					<br>
					<?php if(in_array("Your Email or password was incorrect,try again.<br>", $error_array)) echo  "Your Email or password was incorrect,try again.<br>"; ?>
					<input type="submit" name="login_button" value="Login">
					<br>
					<a href="#" id="signup" class="signup">Need an account? Register here!</a>
					<h5> please do not share your login details with anyone.</h5>

				</form>

			</div>








<div id="second">


<form action="register.php" method="POST">
<input type="text" name="reg_fname" placeholder="First Name" required>
<br>
<?php if(in_array("Your first name has to be between 2 and 30 characters<br>", $error_array)) echo "Your first name has to be between 2 and 30 characters<br>";?>
<input type="text" name="reg_lname" placeholder="Last Name" required>
<br>
<?php if(in_array("Your last name has to be between 2 and 30 characters<br>", $error_array)) echo "Your last name has to be between 2 and 30 characters<br>";?>
<input type="email" name="reg_email" placeholder="Email" required>
<br>
<input type="email" name="reg_email2" placeholder="Confirm Email" required>
<br>
<?php if(in_array("This Email is already in use<br>", $error_array)) echo "This Email is already in use<br>";
else if(in_array("Your email format is correct<br>", $error_array)) echo "Your email format is correct<br>";
else if(in_array("The Emails you have entered do not match<br>", $error_array)) echo "The Emails you have entered do not match<br>";?>
<input type="password" name="reg_password" placeholder="Password" required>
					<br>
					<input type="password" name="reg_password2" placeholder="Confirm Password" required>
					<br>
					<?php if(in_array("Your passwords do not match<br>", $error_array)) echo "Your passwords do not match<br>"; 
					else if(in_array("Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.<br>", $error_array))
echo "Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.<br>"; ?>
<input type="submit" name="register_button" value='Register'>
<br>
					<a href="#" id="signin" class="signin">Already have an account? Sign in here!</a>
</form>
</div>

</div>
</body>
</html>
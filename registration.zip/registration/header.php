<?php
require 'config.php'; 

if (isset($_SESSION['username'])) {
	$userLoggedIn = $_SESSION['username'];
	$user_details_query = mysqli_query($con, "SELECT * FROM users WHERE username='$userLoggedIn'");
	$user = mysqli_fetch_array($user_details_query);
}
else {
	header("Location: register.php");
}
?>
<html>
<head>
	<title>Deadsprint</title>
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div class="top_bar"> 
<div class="logo">
<a>Deadsprint</a>
</div>
<nav>	
<a href="#">
<?php echo $user['first_name']; ?>
<a href="#">
<i class="fa fa-home fa-lg"></i>
<a href="logout.php">
<i class="fa fa-sign-out fa-lg"></i>
		</nav>
		</nav>

	</div>

<div class="wrapper">


